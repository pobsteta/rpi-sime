stdnum.ch.vat
=============

.. automodule:: stdnum.ch.vat
   :members: