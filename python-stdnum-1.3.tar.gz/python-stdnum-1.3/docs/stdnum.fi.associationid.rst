stdnum.fi.associationid
=======================

.. automodule:: stdnum.fi.associationid
   :members: