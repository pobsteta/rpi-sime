stdnum.fi.hetu
==============

.. automodule:: stdnum.fi.hetu
   :members:
