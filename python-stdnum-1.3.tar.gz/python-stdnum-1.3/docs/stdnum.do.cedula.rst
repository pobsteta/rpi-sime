stdnum.do.cedula
================

.. automodule:: stdnum.do.cedula
   :members: