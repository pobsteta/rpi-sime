stdnum.luhn
===========

.. automodule:: stdnum.luhn
   :members:
