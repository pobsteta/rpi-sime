stdnum.isbn
===========

.. automodule:: stdnum.isbn
   :members:
