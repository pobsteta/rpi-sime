stdnum.isin
===========

.. automodule:: stdnum.isin
   :members: