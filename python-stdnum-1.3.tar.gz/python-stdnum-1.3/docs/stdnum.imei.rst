stdnum.imei
===========

.. automodule:: stdnum.imei
   :members:
