stdnum.my.nric
==============

.. automodule:: stdnum.my.nric
   :members:
