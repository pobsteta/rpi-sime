stdnum.pl.pesel
===============

.. automodule:: stdnum.pl.pesel
   :members: